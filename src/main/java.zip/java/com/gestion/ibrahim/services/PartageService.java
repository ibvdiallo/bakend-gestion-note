package com.gestion.ibrahim.services;

import java.util.List;

import com.gestion.ibrahim.entite.Note;
public interface PartageService {
	
}