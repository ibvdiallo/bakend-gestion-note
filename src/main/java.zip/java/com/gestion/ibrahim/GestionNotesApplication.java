package com.gestion.ibrahim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionNotesApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionNotesApplication.class, args);
	}
	
}
